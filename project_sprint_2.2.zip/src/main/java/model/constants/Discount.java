package model.constants;

public class Discount {
    public static final double RED_APPLE_DISCOUNT = 60.0;
    public static final double NON_DISCOUNT = 0.0;
    // создал константу для дефолтного значения скидки
}